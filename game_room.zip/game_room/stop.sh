#!/bin/sh
cat ./program_log/loginserver.pid | xargs kill
