#!/bin/sh
../skynet/skynet config/config.login
