
local function initialize(tableFrame)
end

return {
	initialize = initialize,
}
