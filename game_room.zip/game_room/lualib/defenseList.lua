return {
	isOpen = 1,--0表示关闭，不启用
	vipList = {
		{RMB=488,ipAddr="buyuserver808fd8854fed0fa0.thsgame.com",ip="116.62.7.63"},
		{RMB=30,ipAddr="buyuserverc7c5771e9c981e53.thsgame.com",ip="116.62.7.45"},
	},

	normalList = {
		{Gold=2000,Sign=7,RescueCoin=3,RMB=2,ipAddr="buyuserverb6cd5ddc1bb0c130.thsgame.com",ip="101.37.69.231"},--(Gold and Sign and RescueCoin) or RMB
	},

	dubiousList = {
		{StartUserId=1,EndUserId=3000,ipAddr="buyuserver078b5c0b71c4357.thsgame.com",ip="116.62.7.237"},
		{StartUserId=3001,EndUserId=4700,ipAddr="buyuserver078b5c0b71c4357.thsgame.com",ip="116.62.7.237"},
		{StartUserId=5501,EndUserId=6406,ipAddr="buyuserver078b5c0b71c4357.thsgame.com",ip="116.62.7.237"},
		{StartUserId=4701,EndUserId=5500,ipAddr="buyuserver078b5c0b71c4357.thsgame.com",ip="116.62.7.237"},
	},

	newList = {
		{Sign=0,RescueCoin=0,ipAddr="buyuserver980c7e694d03b606.thsgame.com",ip="101.37.71.54"},
	},
}
