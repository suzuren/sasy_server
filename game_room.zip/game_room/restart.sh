#!/bin/sh
./stop.sh
sleep 1
../skynet/skynet config/config.login
